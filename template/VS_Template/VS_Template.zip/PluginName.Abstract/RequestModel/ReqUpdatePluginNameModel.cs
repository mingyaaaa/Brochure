﻿namespace Plugin.Abstract.ResponseModel
{
    /// <summary>
    /// The req update user model.
    /// </summary>
    public class ReqUpdate$ext_safeprojectname$Model
    {
    }
}