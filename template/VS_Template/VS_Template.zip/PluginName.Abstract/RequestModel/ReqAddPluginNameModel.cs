﻿namespace Plugin.Abstract.RequestModel
{
    public class ReqAdd$ext_safeprojectname$Model
    {
    }
}