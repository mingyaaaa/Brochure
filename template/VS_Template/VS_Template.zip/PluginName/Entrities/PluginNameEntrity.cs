﻿using Brochure.ORM;

namespace PluginTemplate.Entrities
{
    public class $safeprojectname$Entrity : EntityBase, IEntityKey<string>
    {
        public string Id { get; set; }
    }
}